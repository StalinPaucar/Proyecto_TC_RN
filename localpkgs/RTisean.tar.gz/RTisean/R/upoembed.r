upoembed <- function(data,d,m=2,p=1,l,x=0,c=1){
	stop("not yet implemented")
}
