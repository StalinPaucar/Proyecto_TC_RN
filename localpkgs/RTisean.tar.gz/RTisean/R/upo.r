upo <- function(series,m=-1,r=-1,v=-1,p=1,w=-1,W=-1,a=-1,s=-1,n=-1,l=-1,x=0,c=1,pretty=FALSE){ #C
	stop("not yet implemented")
}
