notch <- function(series,X,f=1,w,l,x=0,c=1){
	stop("not yet implemented")
	#out=call_TISEANF_extended(series,options,"notch")
	#return(out)
}
